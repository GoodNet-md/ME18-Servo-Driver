#include "userTools.h"


uint8_t FuncName[][15] = {
    "#ResetFunc##",
    "#StandbyFunc",
    "#FOCFunc####",
    "#ControlFunc",
    "#NoneFunc###"
};

int UARTDecode(uint8_t *rxbuffer, uint32_t *recvFlag){
    int Num[4], resNum;
    Num[0] = rxbuffer[0] - '0';
    Num[1] = rxbuffer[1] - '0';
    Num[2] = rxbuffer[2] - '0';
    Num[3] = rxbuffer[3] - '0';
    resNum = Num[1]*100+Num[2]*10+Num[3];
    if(Num[0] == 1){
        *recvFlag = ResetFunc;
        return 1;
    }
    if(Num[0] == 2){
        *recvFlag = StandbyFunc;
        return 2;
    }
    if(Num[0] == 3){
        *recvFlag = FOCFunc;
        return 3;
    }
    *recvFlag = ControlFunc | resNum<<8;
    return resNum+Num[0]*1000;
}