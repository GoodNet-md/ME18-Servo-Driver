#ifndef USERTOOLS
#define USERTOOLS
#include <stdint.h>


typedef enum {
    ResetFunc = 0,
    StandbyFunc,
    FOCFunc,
    ControlFunc,
    NoneFunc
}FUNC_CODE;

extern uint8_t FuncName[][15];

int UARTDecode(uint8_t *rxbuffer, uint32_t *recvFlag);
#endif